# Data Mining Final Project Source Code Package

This archive contains the source code, dependency files, raw public datasets, tests, and selected result artifacts needed to reproduce the final credit-risk screening results.

Repository: https://github.com/godsoftware/Data_Mining_Project

## Package contents

- `src/`: reusable project modules.
- `experiments/`: numbered experiment scripts. The intended execution order is numeric, from `00_...` through `47_...`.
- `tests/`: checks for leakage, metrics, preprocessing, calibration, thresholding, subgroup reliability, and phase outputs.
- `data/raw/`: public Taiwan credit-card default and HELOC raw datasets used by the project.
- `outputs_reference/`: selected final evidence artifacts used to verify the reported results without including the full generated-output directory.
- `requirements.txt` and `environment.yml`: dependency specifications.
- `run_all.py`: runner for the core pipeline steps.

## Environment setup

Python 3.10 is recommended.

Using `venv`:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Using Conda:

```powershell
conda env create -f environment.yml
conda activate scre-credit
```

## Reproduction instructions

Run from the archive root after installing dependencies.

1. Check the environment and input files:

```powershell
python experiments/00_environment_check.py
```

2. Run the core project pipeline:

```powershell
python run_all.py
```

The runner executes the main preparation, modeling, calibration, thresholding, explainability, external-validation, statistical-test, and ablation steps. It supports partial execution:

```powershell
python run_all.py --start-at 09_calibration --stop-after 12_statistical_tests
```

3. Reproduce the final decision and audit artifacts by running the remaining numbered scripts in order:

```powershell
Get-ChildItem experiments\*.py |
  Sort-Object Name |
  Where-Object { $_.Name -match '^[2-4][0-9]_' } |
  ForEach-Object { python $_.FullName }
```

4. Run the test suite:

```powershell
pytest tests
```

## Expected final evidence locations

After a complete run, the main final evidence should be regenerated under:

- `outputs/decision_revision_v2/`
- `outputs/final_frozen_v2/`
- `outputs/final_weakness_closing/`
- `outputs/tables/`

The `outputs_reference/` directory in this archive contains selected already-generated artifacts for comparison with a reproduced run. It is not required as input for training or scoring.

## Data note

Taiwan and HELOC are modeled separately. HELOC is used to test framework portability under a different public credit-risk schema; it is not produced by transforming Taiwan features into HELOC features.
